#/bin/sh

rm -Rf /home/julien/Documents/AnkiTest
cp -R /home/julien/Documents/AnkiModel /home/julien/Documents/AnkiTest

