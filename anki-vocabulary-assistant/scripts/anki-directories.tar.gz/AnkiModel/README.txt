This folder stores all of your Anki data in a single location,
to make backups easy. To tell Anki to use a different location,
please see:

http://ankisrs.net/docs/manual.html#startupopts
